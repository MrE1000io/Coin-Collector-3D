using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LoadSceneManager : MonoBehaviour
{
    private static LoadSceneManager instance;


    public GameObject carga;


    public static void LoadScene(int index)
    {
        instance.StartCoroutine(instance.NextScene(index));
    }

    public IEnumerator NextScene(int index)
    {
        carga.SetActive(true);

        yield return new WaitForSeconds(5);

        carga.SetActive(false);
    }
}
