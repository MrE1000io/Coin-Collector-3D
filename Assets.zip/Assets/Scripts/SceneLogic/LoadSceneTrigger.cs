using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class LoadSceneTrigger : MonoBehaviour
{
    public int nextScene;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            StartCoroutine(LoadSceneAfterDelay(1f)); // 1 segundo de espera
        }
    }

    private IEnumerator LoadSceneAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        SceneManager.LoadScene(nextScene);
    }
}

