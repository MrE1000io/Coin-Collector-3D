using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TitleController : MonoBehaviour
{
    public GameObject title;


    private void Start()
    {
        title.SetActive(false);
    }

    private void Update()
    {
        if (transform.position.y < -10)
        {
            StartCoroutine(CerrarTitulo());
        }
    }

    IEnumerator CerrarTitulo()
    {
        title.SetActive(true);
        yield return new WaitForSeconds(5);
        title.SetActive(false);
        GameOver();
    }
    
    public void GameOver()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
