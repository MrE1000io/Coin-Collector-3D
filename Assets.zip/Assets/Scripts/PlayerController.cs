using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UIElements;

public class PlayerController : MonoBehaviour
{
    private Vector2 movimiento;

    public Rigidbody rig;

    public float velMov;

    public float fuerzaSalto;

    private bool isGrounded;

    

    public TextMeshProUGUI contador;
    private int suma = 0;

    public void InputMovimiento(InputAction.CallbackContext context)
    {
        if (context.performed)
            movimiento = context.ReadValue<Vector2>();
        else if (context.canceled)
            movimiento = Vector2.zero;
    }

    private void FixedUpdate()
    {
        rig.velocity = new Vector3(movimiento.x * velMov, rig.velocity.y, movimiento.y * velMov);

        Vector3 dirRotacion = rig.velocity;
        dirRotacion.y = 0;

        if (dirRotacion.x != 0 || dirRotacion.z != 0)
            transform.forward = dirRotacion;
    }

    public void InputSystemSalto(InputAction.CallbackContext context)
    {
        if (context.started)
        {
            if (isGrounded == true)
            {
                rig.AddForce(Vector3.up * fuerzaSalto, ForceMode.Impulse);
                isGrounded = false;
            }
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("suelo"))
            isGrounded = true;
    }

    public void ContadorMarcador(int puntuacion)
    {
        suma += puntuacion;
        contador.text = suma.ToString();
    }
    
    public void AddScore(int amount)
    {
        suma += amount;
        contador.text = suma.ToString();
    }
}
